<?php
// newsmunch_hdr_left_ttl
function newsmunch_hdr_left_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_hdr_left_ttl' );
}

// newsmunch_hdr_top_ads_title
function newsmunch_hdr_top_ads_title_render_callback() {
	return get_theme_mod( 'newsmunch_hdr_top_ads_title' );
}

// newsmunch_hdr_btn_lbl
function newsmunch_hdr_btn_lbl_render_callback() {
	return get_theme_mod( 'newsmunch_hdr_btn_lbl' );
}

// newsmunch_top_tags_ttl
function newsmunch_top_tags_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_top_tags_ttl' );
}

// newsmunch_hlatest_story_ttl
function newsmunch_hlatest_story_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_hlatest_story_ttl' );
}

// newsmunch_slider_ttl
function newsmunch_slider_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_slider_ttl' );
}

// newsmunch_slider_mdl_ttl
function newsmunch_slider_mdl_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_slider_mdl_ttl' );
}

// newsmunch_slider_right_ttl
function newsmunch_slider_right_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_slider_right_ttl' );
}

// newsmunch_featured_link_ttl
function newsmunch_featured_link_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_featured_link_ttl' );
}

// newsmunch_you_missed_ttl
function newsmunch_you_missed_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_you_missed_ttl' );
}

// newsmunch_about_ttl
function newsmunch_about_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_about_ttl' );
}

// newsmunch_about_subttl
function newsmunch_about_subttl_render_callback() {
	return get_theme_mod( 'newsmunch_about_subttl' );
}

// newsmunch_about_text
function newsmunch_about_text_render_callback() {
	return get_theme_mod( 'newsmunch_about_text' );
}

// newsmunch_about_btn_lbl
function newsmunch_about_btn_lbl_render_callback() {
	return get_theme_mod( 'newsmunch_about_btn_lbl' );
}

// newsmunch_skill_ttl
function newsmunch_skill_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_skill_ttl' );
}

// newsmunch_skill_subttl
function newsmunch_skill_subttl_render_callback() {
	return get_theme_mod( 'newsmunch_skill_subttl' );
}

// newsmunch_skill_text
function newsmunch_skill_text_render_callback() {
	return get_theme_mod( 'newsmunch_skill_text' );
}

// newsmunch_team_ttl
function newsmunch_team_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_team_ttl' );
}

// newsmunch_faq_ttl
function newsmunch_faq_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_faq_ttl' );
}

// newsmunch_contact_form_ttl
function newsmunch_contact_form_ttl_render_callback() {
	return get_theme_mod( 'newsmunch_contact_form_ttl' );
}