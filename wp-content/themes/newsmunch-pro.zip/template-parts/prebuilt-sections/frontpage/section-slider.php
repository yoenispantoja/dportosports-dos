<?php 
$newsmunch_slider_right_type		= get_theme_mod('newsmunch_slider_right_type','style-1');
// if($newsmunch_slider_right_type=='style-1'):
get_template_part('template-parts/prebuilt-sections/frontpage/section','slider-1');
// elseif($newsmunch_slider_right_type=='style-7'):
// get_template_part('template-parts/prebuilt-sections/frontpage/section','slider-3');
// else:
// get_template_part('template-parts/prebuilt-sections/frontpage/section','slider-1');
// endif;
?>